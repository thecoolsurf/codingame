SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE IF NOT EXISTS `body` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `body` (`id`, `title`, `slug`, `description`) VALUES
(1, 'Home', 'home', 'Codez mieux\r\nProgressez en résolvant des challenges dans 25+ langages de programmation et technologies du moment.\r\nApprenez des meilleurs\r\nExplorez de nouveaux frameworks, langages ou algorithmes à travers des jeux et tutoriels créés par les meilleurs programmeurs.\r\nDevenez un expert\r\nNotre approche a été conçue pour accompagner les développeurs confirmés dans leur passage au niveau supérieur.'),
(2, 'About', 'about', 'Chez CodinGame, notre but est de permettre aux développeurs d\'améliorer leurs compétences en continu en résolvant les problèmes de code les plus motivants et en échangeant avec les meilleurs programmeurs du monde.'),
(3, 'Practice', 'practice', 'La section des exercices suivant est consacrée aux développeurs PHP par le site Codingame afin de leur permettre de progresser dans leur language. Chaque exercice aborde un problème que le développeur doit résoudre en proposant le code solution.'),
(4, 'Login', 'login', 'If you want to access the section ADMIN to this website, you must login with your email and password.');

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `category` (`id`, `title`, `slug`) VALUES
(1, 'PHP', 'php'),
(2, 'MySQL', 'mysql'),
(3, 'Javascript', 'javascript');

CREATE TABLE IF NOT EXISTS `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_id` int(11) DEFAULT NULL,
  `response_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `IDX_B6F7494E1E27F6BF` (`categories_id`),
  KEY `FK_B6F7494EFBF32840` (`response_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `question` (`id`, `categories_id`, `response_id`, `title`, `description`) VALUES
(1, 1, 1, 'Question N°1', 'Utiliser une boucle pour générer une liste déroulante dont les value value seront les nombres de 1 à 10 et les valeurs affichées seront le nombre suivi de pair pour les nombres pairs et impair pour les nombres impairs :'),
(2, 1, 2, 'PHP exercice 2', 'Afficher la table de multiplication des nombres de 1 à 10 sous la forme d’un tableau carré de 11 cases sur 11.'),
(3, 1, 3, 'PHP exercice 3', 'Remplir un tableau de dimensions 10x10 de valeurs aléatoires comprises entre -50 et 50 et compter les valeurs positives, négatives et nulles.\nAfficher le tableau sous forme tabulaire, puis les valeurs calculées.'),
(4, 1, 4, 'PHP exercice 4', 'Demander à l’utilisateur les coordonnées de deux points : $x1, $x2, $y1 et $y2. Calculer et afficher la distance d entre les deux points X1 et X2, avec la formule :\n√(x2−x1)2+(y2−y1)2'),
(5, 1, 5, 'PHP exercice 5', 'Enoncé de la question.'),
(6, 2, 1, 'MYSQL exercice 1', 'Enoncé de la question.'),
(7, 2, 2, 'MYSQL exercice 2', 'Enoncé de la question.'),
(8, 2, 3, 'MYSQL exercice 3', 'Enoncé de la question.'),
(9, 2, 4, 'MYSQL exercice 4', 'Enoncé de la question.'),
(10, 2, 5, 'MYSQL exercice 5', 'Enoncé de la question.'),
(11, 3, 1, 'JAVASCRIPT exercice 1', 'Enoncé de la question.'),
(12, 3, 2, 'JAVASCRIPT exercice 2', 'Enoncé de la question.'),
(13, 3, 3, 'JAVASCRIPT exercice 3', 'Enoncé de la question.'),
(14, 3, 4, 'JAVASCRIPT exercice 4', 'Enoncé de la question.'),
(15, 3, 5, 'JAVASCRIPT exercice 5', 'Enoncé de la question.');

CREATE TABLE IF NOT EXISTS `response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) DEFAULT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3E7B0BFB1E27F6BF` (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `response` (`id`, `question_id`, `answer`) VALUES
(1, 1, '<select><br />\n    {% for i in datas %}<br />\n        {% set j = loop.index %}<br />\n        <option value=\"{{ j }}\">{{ j ~ \' - \' ~ i }}</option><br />\n    {% endfor %}<br />\n</select><br />\n\n                                    '),
(2, 2, '                                                            <table class=\"table\">\n                    <thead>\n                        <tr>\n                            {% for i in 1..max %}\n                            <th scope=\"col\">\n                                {{ i~\'x\' }}\n                            </th>\n                            {% endfor %}\n                        </tr>\n                    </thead>\n                    <tbody>\n                        {% for j in 1..max %}\n                        <tr>\n                            {% for i in 1..max %}\n                            <td scope=\"row\">\n                                {{ i * j }}\n                            </td>\n                            {% endfor %}\n                        </tr>\n                        {% endfor %}\n                    </tbody>    \n                </table>\n\n                                    '),
(3, 3, '<table class=\"table\">\n                    <thead>\n                        <tr>\n                            {% for i in 1..max %}\n                                <th scope=\"col\">\n                                    {{ i }}\n                                </th>\n                            {% endfor %}\n                        </tr>\n                    </thead>\n                    <tbody>\n                        {% for i in 1..max %}\n                            <tr>\n                                {% for j in 1..max %}\n                                    {% set k = (i*j)-1 %}\n                                    <td scope=\"row\">\n                                        {{ datas[k] }}\n                                    </td>\n                                {% endfor %}\n                            </tr>\n                        {% endfor %}\n                        <tr>\n                            <td colspan=\"10\">\n                                {{ \'Null values: \'~ count_a~\' - \' }}\n                                {{ \'Positives values: \' ~ count_b~\' - \' }}\n                                {{ \'Negatives values: \' ~ count_c }}\n                            </td>\n                        </tr>\n                    </tbody>    \n                </table>\n            '),
(4, 4, 'sqrt(pow(($lgx-$ltx),2)+pow(($lgy-$lty),2));'),
(5, 5, ''),
(6, 6, ''),
(7, 7, ''),
(8, 8, ''),
(9, 9, ''),
(10, 10, ''),
(11, 11, ''),
(12, 12, ''),
(13, 13, ''),
(14, 14, ''),
(15, 15, '');

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zipcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user` (`id`, `lastname`, `firstname`, `email`, `roles`, `username`, `password`, `phone`, `address`, `zipcode`, `city`) VALUES
(1, 'DOUIN', 'Hubert', 'douinh@gmail.com', '[\"ROLE_ADMIN\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$+AW9ONhg6AzZ6ZQf+NTwuw$04G36rRORGjqYlB4bjEN2Lkn3c/VuYFV5ffWrLOFYks', '06 18 17 19 18', '260 O\'Hara Hill Apt. 935', '75015', 'PARIS'),
(2, 'STAMM', 'Emory', 'emory.stamm@gmail.com', '[\"ROLE_USER\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$RvNLEty35Eu9pk+btD/mdg$nwm1vMITQSl/NRW4lugFKAv6tmBZfnEY7uVYUVgcr6M', '06 13 15 12 15', '597 Heloise Neck Apt. 565', '75019', 'PARIS'),
(3, 'WEIMANN', 'Clotilde', 'clotilde.weimann@gmail.com', '[\"ROLE_USER\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$o0YH94bMHR+0qMjxRu1XBQ$waYZTCs4q50KLCAXNf+jQvYHgsNEjgRgtdvLdICTciA', '06 11 17 19 11', '56923 Streich Turnpike Suite 919', '75011', 'PARIS'),
(4, 'WISOKY', 'Clifford', 'clifford.wisoky@gmail.com', '[\"ROLE_USER\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$QYVkI0h/EPDkCtNlRd4/Fw$2/VY6tlXcoZu5T7T0Af/bWlz384FTt1aGTbwt7spm5k', '06 10 11 16 19', '9333 Koepp Squares', '75013', 'PARIS'),
(5, 'GRANT', 'Betty', 'betty.grant@gmail.com', '[\"ROLE_USER\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$WfQiV+1aomX0dhxZGV5XKQ$k45s3gib+tOWhMiHuTEBBlRlIvIbJWZpY/OcwTTOkoo', '06 13 12 11 14', '62446 Hayes Shoals Suite 724', '75014', 'PARIS'),
(6, 'SCHAMBERGER', 'Stanford', 'stanford.schamberger@gmail.com', '[\"ROLE_USER\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$CXgtUdImm37FWShOrC3F7A$lqfuFzqoyQ1bM6iY0NvBo1lsdKVNiuewEB1uXkzX8xw', '06 10 15 15 10', '71009 Joan Brook Apt. 325', '75020', 'PARIS'),
(7, 'EFFERTZ', 'Demetris', 'demetris.effertz@gmail.com', '[\"ROLE_USER\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$IWnJ4r097jQgvPjv/M8dKQ$q5rieWdcRPc5baQnkE8FrCVvL8tstgeNuXKcrQs5i9o', '06 16 14 15 10', '8613 McKenzie Rue Apt. 231', '75019', 'PARIS'),
(8, 'LEMKE', 'Ubaldo', 'ubaldo.lemke@gmail.com', '[\"ROLE_USER\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$Adw9AsFk7jM3dYYXK9/gbQ$D6Er/WOE2SWNX5RvpyQjEM7c8tu17UBEDTAZOb2tjXg', '06 16 14 15 15', '953 Stracke Mission', '75018', 'PARIS'),
(9, 'BEIER', 'Leola', 'leola.beier@gmail.com', '[\"ROLE_USER\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$tWXGJOhngtPDgK6DFWNLsg$I0FGlgWYUCVGpYnq/lM0qBjaRXlrDfuePzo4/NqLeCY', '06 11 11 14 18', '21052 Mohr Mountains', '75019', 'PARIS'),
(10, 'HEATHCOTE', 'Lydia', 'lydia.heathcote@gmail.com', '[\"ROLE_USER\"]', NULL, '$argon2id$v=19$m=65536,t=4,p=1$w50CFhQXhiARqlbjTzAu6w$dSn/SmerYq1EtsAn9oOXpO0Bup/htayIXpXO7IbcFiU', '06 13 15 12 16', '388 O\'Connell Shoals Suite 348', '75012', 'PARIS');


ALTER TABLE `question`
  ADD CONSTRAINT `FK_B6F7494E1E27F6BF` FOREIGN KEY (`categories_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `FK_B6F7494EFBF32840` FOREIGN KEY (`response_id`) REFERENCES `response` (`id`);

ALTER TABLE `response`
  ADD CONSTRAINT `FK_3E7B0BFB1E27F6BF` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
