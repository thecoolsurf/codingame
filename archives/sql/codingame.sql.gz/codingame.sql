SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE IF NOT EXISTS `body` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `body` (`id`, `title`, `slug`, `description`) VALUES
(5, 'Home', 'home', 'Codez mieux Progressez en résolvant des challenges dans 25+ langages de programmation et technologies du moment. Apprenez des meilleurs Explorez de nouveaux frameworks, langages ou algorithmes à travers des jeux et tutoriels créés par les meilleurs programmeurs. Devenez un expert Notre approche a été conçue pour accompagner les développeurs confirmés dans leur passage au niveau supérieur.'),
(6, 'About', 'about', 'Chez CodinGame, notre but est de permettre aux développeurs d\'améliorer leurs compétences en continu en résolvant les problèmes de code les plus motivants et en échangeant avec les meilleurs programmeurs du monde.'),
(7, 'Practice', 'practice', 'La section des exercices suivant est consacrée aux développeurs PHP par le site Codingame afin de leur permettre de progresser dans leur language. Chaque exercice aborde un problème que le développeur doit résoudre en proposant le code solution.'),
(8, 'Login', 'login', 'If you want to access the section ADMIN to this website you must be logged in.');

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `category` (`id`, `title`, `slug`) VALUES
(4, 'Php', 'php'),
(5, 'Javascript', 'javascript'),
(6, 'Mysql', 'mysql');

CREATE TABLE IF NOT EXISTS `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20200718074440', '2020-07-18 09:46:07', 128);

CREATE TABLE IF NOT EXISTS `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `IDX_B6F7494EA21214B7` (`categories_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `question` (`id`, `categories_id`, `title`, `description`) VALUES
(16, 4, 'Exercice php N°1', 'Description de l\'exercice php N°1'),
(17, 4, 'Exercice php N°2', 'Description de l\'exercice php N°2'),
(18, 4, 'Exercice php N°3', 'Description de l\'exercice php N°3'),
(19, 4, 'Exercice php N°4', 'Description de l\'exercice php N°4'),
(20, 4, 'Exercice php N°5', 'Description de l\'exercice php N°5'),
(21, 5, 'Exercice javascript N°1', 'Description de l\'exercice javascript N°1'),
(22, 5, 'Exercice javascript N°2', 'Description de l\'exercice javascript N°2'),
(23, 5, 'Exercice javascript N°3', 'Description de l\'exercice javascript N°3'),
(24, 5, 'Exercice javascript N°4', 'Description de l\'exercice javascript N°4'),
(25, 5, 'Exercice javascript N°5', 'Description de l\'exercice javascript N°5'),
(26, 6, 'Exercice mysql N°1', 'Description de l\'exercice mysql N°1'),
(27, 6, 'Exercice mysql N°2', 'Description de l\'exercice mysql N°2'),
(28, 6, 'Exercice mysql N°3', 'Description de l\'exercice mysql N°3'),
(29, 6, 'Exercice mysql N°4', 'Description de l\'exercice mysql N°4'),
(30, 6, 'Exercice mysql N°5', 'Description de l\'exercice mysql N°5');

CREATE TABLE IF NOT EXISTS `response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) DEFAULT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3E7B0BFB1E27F6BF` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `username` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user` (`id`, `lastname`, `firstname`, `email`, `roles`, `username`, `password`, `phone`, `address`, `zipcode`, `city`) VALUES
(11, 'THIBAULT', 'Dominique', 'renee76@tiscali.fr', '[\"ROLE_ADMIN\"]', 'user01', '$argon2id$v=19$m=65536,t=4,p=1$cxfYjuk/iA1Na6jGmj2Zag$pzuBGOCgijufJ5+gzTJr5mL10VFrP3trYfMyo0kO/lE', '0418626021', '93, place Frédéric Deschamps\n20 445 Torresnec', '46 229', 'DELANNOY'),
(12, 'GERMAIN', 'Hélène', 'uperon@yahoo.fr', '[\"ROLE_USER\"]', 'user02', '$argon2id$v=19$m=65536,t=4,p=1$1fxpGAvK+sQnTNJsjwyQGQ$QeJInEA2VRaZM+Xtyd2bbLnuFZ5Kexw15zlMKqteVzI', '+33 (0)7 89 68 26 15', '7, impasse Susanne Jourdan\n16 783 Benoit-sur-Payet', '11856', 'NEVEU-SUR-MER'),
(13, 'PINEAU', 'Yves', 'constance.jean@live.com', '[\"ROLE_USER\"]', 'user03', '$argon2id$v=19$m=65536,t=4,p=1$aGD5vy/tK4PpQCBC9Ta4Nw$TQ3/YFiH+noVukf3r63IHcCztMedcqhslrYs6ufcwfA', '+33 (0)5 31 70 38 33', '19, boulevard Leleu\n74816 Moreno-sur-Mer', '22 212', 'BOYER-SUR-GILBERT'),
(14, 'BOUCHET', 'Thomas', 'vaillant.benjamin@lejeune.com', '[\"ROLE_USER\"]', 'user04', '$argon2id$v=19$m=65536,t=4,p=1$ufg6zN0Mbnu5ffGHV3kyOg$FbLX4nR/dFBVnn/upuoL+6T5p4DoRXMnbQYecInKYfY', '+33 (0)3 32 56 79 82', '726, boulevard Louis Remy\n85 558 Jacques-sur-Bruneau', '23101', 'DELATTRE-SUR-BRETON'),
(15, 'TRAORE', 'Jeannine', 'rene53@wanadoo.fr', '[\"ROLE_USER\"]', 'user05', '$argon2id$v=19$m=65536,t=4,p=1$O6g7m8hEbFLYDLDbZbqamQ$iUrk9/RxLoflk1ZGNjVNbX9uVguGLuAIl4VtlaFvmrI', '0686430711', '9, rue Isaac Labbe\n13927 Caron', '60 683', 'DELAHAYE-LES-BAINS'),
(16, 'PAGES', 'Dorothée', 'didier.simone@tiscali.fr', '[\"ROLE_USER\"]', 'user06', '$argon2id$v=19$m=65536,t=4,p=1$xx5+FsYFzN/S/UPuQJx4xQ$pf1FSjVLMEcRPsGxeDQ38sQt3rtdIPKEfyvag7tUNR8', '+33 2 62 36 72 20', '33, chemin Bonnin\n57 422 Chretien', '66344', 'LEGER'),
(17, 'BOYER', 'Robert', 'marty.william@rousseau.net', '[\"ROLE_USER\"]', 'user07', '$argon2id$v=19$m=65536,t=4,p=1$MOArxP/vJzRRqYhbZivK3Q$X06iaOdFh70yOCHPAuaO86YxMMPfurDBY4NBAMBRAzM', '+33 5 75 86 99 78', 'boulevard Levy\n23 153 Mathieu', '57 863', 'ROBERT'),
(18, 'JACQUOT', 'Michel', 'godard.ines@salmon.fr', '[\"ROLE_USER\"]', 'user08', '$argon2id$v=19$m=65536,t=4,p=1$/oj6GjXdPpKHP/Tl0E1cMg$9GC0Md4MaQYpimN+G/RzedLL2x7XYr8f9UlBSf0r31s', '+33 (0)3 83 16 92 58', '9, avenue de Gautier\n06 313 Devaux-la-Forêt', '23 036', 'CHAUVIN'),
(19, 'AUBERT', 'Suzanne', 'benjamin17@gosselin.org', '[\"ROLE_USER\"]', 'user09', '$argon2id$v=19$m=65536,t=4,p=1$ribWdZM3GG4pds1+dtQRyQ$MvdKblTr2K3dvEVIHUbC6m0ql3xXOsOmsWmZIQmsZLg', '+33 (0)1 89 81 26 60', '21, avenue Arnaud\n03587 Duhamel', '77089', 'GUERIN'),
(20, 'ALBERT', 'Virginie', 'claude18@noos.fr', '[\"ROLE_USER\"]', 'user10', '$argon2id$v=19$m=65536,t=4,p=1$w5CgglTYFt6RjpH5dRWEWA$GYy1BB3i/SVji2Pojw9qc/6c/YnYLO01cZSfMfq9ptg', '0806911009', '76, avenue Maillard\n12 976 Berthelot', '36081', 'BENOITBOURG');


ALTER TABLE `question`
  ADD CONSTRAINT `FK_B6F7494E1E27F6BF` FOREIGN KEY (`categories_id`) REFERENCES `category` (`id`);

ALTER TABLE `response`
  ADD CONSTRAINT `FK_3E7B0BFB1E27F6BF` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
