SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE IF NOT EXISTS `body` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `h2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paragraph` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DBA80BB2C4663E4` (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `body` (`id`, `page_id`, `h2`, `paragraph`, `icon`) VALUES
(1, 1, 'Code', 'Code better Progress by solving challenges in 25+ programming languages and current technologies.', 'fa fa-code'),
(2, 2, 'About us', 'At CodinGame, our goal is to enable developers to continuously improve their skills by solving the most motivating code problems and interacting with the best programmers in the world.', NULL),
(3, 3, 'Practice coding', 'The following exercises section is dedicated to PHP developers on the Codingame site in order to allow them to progress in their language. Each exercise addresses a problem that the developer must solve by proposing the solution code.', NULL),
(4, 4, 'Login user', 'If you want to access the section ADMIN to this website you must be logged in.', NULL),
(5, 1, 'Learn', 'Learn from the best Explore new frameworks, languages or algorithms through games and tutorials created by the best programmers.', 'fa fa-graduation-cap'),
(6, 1, 'Become', 'Become an expert Our approach was designed to support experienced developers in their progress to the next level.', 'fa fa-trophy');

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `category` (`id`, `title`, `slug`) VALUES
(1, 'Php', 'php'),
(2, 'Javascript', 'javascript'),
(3, 'Mysql', 'mysql');

CREATE TABLE IF NOT EXISTS `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20200719093411', '2020-07-19 11:34:16', 101),
('DoctrineMigrations\\Version20200720101818', '2020-07-20 12:18:27', 95),
('DoctrineMigrations\\Version20200724113415', '2020-07-24 13:34:26', 45),
('DoctrineMigrations\\Version20200724114143', '2020-07-24 13:41:48', 91);

CREATE TABLE IF NOT EXISTS `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `h1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `page` (`id`, `h1`, `slug`) VALUES
(1, 'Home', 'home'),
(2, 'About', 'about'),
(3, 'Practice', 'practice'),
(4, 'Login', 'login');

CREATE TABLE IF NOT EXISTS `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `IDX_B6F7494EA21214B7` (`categories_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `question` (`id`, `categories_id`, `title`, `description`) VALUES
(1, 1, 'Exercice php N°1', 'Description de l\'exercice php N°1'),
(2, 1, 'Exercice php N°2', 'Description de l\'exercice php N°2'),
(3, 1, 'Exercice php N°3', 'Description de l\'exercice php N°3'),
(4, 1, 'Exercice php N°4', 'Description de l\'exercice php N°4'),
(5, 1, 'Exercice php N°5', 'Description de l\'exercice php N°5'),
(6, 2, 'Exercice javascript N°1', 'Description de l\'exercice javascript N°1'),
(7, 2, 'Exercice javascript N°2', 'Description de l\'exercice javascript N°2'),
(8, 2, 'Exercice javascript N°3', 'Description de l\'exercice javascript N°3'),
(9, 2, 'Exercice javascript N°4', 'Description de l\'exercice javascript N°4'),
(10, 2, 'Exercice javascript N°5', 'Description de l\'exercice javascript N°5'),
(11, 3, 'Exercice mysql N°1', 'Description de l\'exercice mysql N°1'),
(12, 3, 'Exercice mysql N°2', 'Description de l\'exercice mysql N°2'),
(13, 3, 'Exercice mysql N°3', 'Description de l\'exercice mysql N°3'),
(14, 3, 'Exercice mysql N°4', 'Description de l\'exercice mysql N°4'),
(15, 3, 'Exercice mysql N°5', 'Description de l\'exercice mysql N°5');

CREATE TABLE IF NOT EXISTS `response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) DEFAULT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3E7B0BFB1E27F6BF` (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `response` (`id`, `question_id`, `answer`) VALUES
(2, 3, '{% set max = 10 %}\n<table class=\"table\">\n    <thead>\n        <tr>\n            {% for i in 1..max %}\n                <th scope=\"col\">\n                    {{ i }}\n                </th>\n            {% endfor %}\n        </tr>\n    </thead>\n    <tbody>\n        {% for i in 1..max %}\n            <tr>\n                {% for j in 1..max %}\n                    {% set k = (i*j)-1 %}\n                    <td scope=\"row\">\n                        {{ datas[k] }}\n                    </td>\n                {% endfor %}\n            </tr>\n        {% endfor %}\n        <tr>\n            <td colspan=\"10\">\n            {#\n                {{ \'Null values: \'~ count_a~\' - \' }}\n                {{ \'Positives values: \' ~ count_b~\' - \' }}\n                {{ \'Negatives values: \' ~ count_c }}\n            #}\n            </td>\n        </tr>\n    </tbody>    \n</table>'),
(3, 4, 'sqrt(pow(($lgx-$ltx),2)+pow(($lgy-$lty),2));'),
(4, 1, '<select>\n                    <option value=\"1\">option - 1</option>\n                    <option value=\"2\">option - 2</option>\n                    <option value=\"3\">option - 3</option>\n                    <option value=\"4\">option - 4</option>\n                    <option value=\"5\">option - 5</option>\n                    <option value=\"6\">option - 6</option>\n                    <option value=\"7\">option - 7</option>\n                    <option value=\"8\">option - 8</option>\n                    <option value=\"9\">option - 9</option>\n                    <option value=\"10\">option - 10</option>\n    </select>'),
(5, 2, '{% set max = 10 %}\n<table class=\"table\">\n    <thead>\n        <tr>\n        {% for i in 1..max %}\n            <th scope=\"col\">{{ i~\'x\' }}</th>\n        {% endfor %}\n        </tr>\n    </thead>\n    <tbody>\n    {% for j in 1..max %}\n        <tr>\n        {% for i in 1..max %}\n            <td scope=\"row\">{{ i * j }}</td>\n        {% endfor %}\n        </tr>\n    {% endfor %}\n    </tbody>    \n</table>');

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `label`, `name`) VALUES
(1, 'ROLE_ADMIN', 'Administrator'),
(2, 'ROLE_USER', 'User');

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `username` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user` (`id`, `lastname`, `firstname`, `email`, `roles`, `username`, `password`, `phone`, `address`, `zipcode`, `city`) VALUES
(1, 'DOUIN', 'Hubert', 'hdouin@free.fr', '[\"ROLE_ADMIN\"]', 'user01', 'pass01', '06 17 70 42 75', '33 rue Claude Tillier', '75012', 'PARIS'),
(2, 'GERMAIN', 'Hélène', 'uperon@yahoo.fr', '[\"ROLE_USER\"]', 'user02', '$argon2id$v=19$m=65536,t=4,p=1$c75WpEup2HhaKNpLi6rkRQ$kXMXwZfrzlvqODGsEkhHv9ClWO84C+GSV2emhmiNY2I', '+33 (0)7 89 68 26 15', '7, impasse Susanne Jourdan\n16 783 Benoit-sur-Payet', '11856', 'NEVEU-SUR-MER'),
(3, 'PINEAU', 'Yves', 'constance.jean@live.com', '[\"ROLE_USER\"]', 'user03', '$argon2id$v=19$m=65536,t=4,p=1$f++r5IzBIPvoOtkVzntOLA$t5gbtBnewSkDzr7jeQPcEzOhmRhPDZ3AvuMb5jd93IA', '+33 (0)5 31 70 38 33', '19, boulevard Leleu\n74816 Moreno-sur-Mer', '22 212', 'BOYER-SUR-GILBERT'),
(4, 'BOUCHET', 'Thomas', 'vaillant.benjamin@lejeune.com', '[\"ROLE_USER\"]', 'user04', '$argon2id$v=19$m=65536,t=4,p=1$Zw1O4it+1f9eVe8loqerVw$HGEuTuJaGLkvs96r+MMTjpM35QoikMi+LBLeKlz1lWM', '+33 (0)3 32 56 79 82', '726, boulevard Louis Remy\n85 558 Jacques-sur-Bruneau', '23101', 'DELATTRE-SUR-BRETON'),
(5, 'TRAORE', 'Jeannine', 'rene53@wanadoo.fr', '[\"ROLE_USER\"]', 'user05', '$argon2id$v=19$m=65536,t=4,p=1$/JPCf81A8IYbwON+gcNBKg$jSVDHLJOVG5nbfr/O+VrEqDEn/m5f7ZHZzuFGGnMkhY', '0686430711', '9, rue Isaac Labbe\n13927 Caron', '60 683', 'DELAHAYE-LES-BAINS'),
(6, 'PAGES', 'Dorothée', 'didier.simone@tiscali.fr', '[\"ROLE_USER\"]', 'user06', '$argon2id$v=19$m=65536,t=4,p=1$DmBzFRuS6sRvf3DTjtXJog$xKxWA/xDbKrTOJQzNOJRO7jqkEhCuLqzef3gE+eLCmA', '+33 2 62 36 72 20', '33, chemin Bonnin\n57 422 Chretien', '66344', 'LEGER'),
(7, 'BOYER', 'Robert', 'marty.william@rousseau.net', '[\"ROLE_USER\"]', 'user07', '$argon2id$v=19$m=65536,t=4,p=1$UBkcdRvB3MoT2+3e63aYhw$rtuEDo5onZiGtJwHoZSztaWC5EuEIm2hyxEFyAuEdpc', '+33 5 75 86 99 78', 'boulevard Levy\n23 153 Mathieu', '57 863', 'ROBERT'),
(8, 'JACQUOT', 'Michel', 'godard.ines@salmon.fr', '[\"ROLE_USER\"]', 'user08', '$argon2id$v=19$m=65536,t=4,p=1$GLVf6iWp7yBegkaW5KuDeA$PtYDU822LXe5PgQPe2wNeBZ3Qr9waDC9KKZShCk/6fQ', '+33 (0)3 83 16 92 58', '9, avenue de Gautier\n06 313 Devaux-la-Forêt', '23 036', 'CHAUVIN'),
(9, 'AUBERT', 'Suzanne', 'benjamin17@gosselin.org', '[\"ROLE_USER\"]', 'user09', '$argon2id$v=19$m=65536,t=4,p=1$hE9z+kMmP/v74Wrs71TWyw$hzZk10cM6YHoe6sx6DrVVXrjn95sTL8flNaTSW+hxU4', '+33 (0)1 89 81 26 60', '21, avenue Arnaud\n03587 Duhamel', '77089', 'GUERIN'),
(10, 'ALBERT', 'Virginie', 'claude18@noos.fr', '[\"ROLE_USER\"]', 'user10', '$argon2id$v=19$m=65536,t=4,p=1$TiFg0l9bSs+NqiXmDWGVXw$O0oNktMR7LqNWtq3UzJUqB1wNaHugC++IDMQ4Y+qCU4', '0806911009', '76, avenue Maillard\n12 976 Berthelot', '36081', 'BENOITBOURG');


ALTER TABLE `body`
  ADD CONSTRAINT `FK_DBA80BB2C4663E4` FOREIGN KEY (`page_id`) REFERENCES `page` (`id`);

ALTER TABLE `question`
  ADD CONSTRAINT `FK_B6F7494E1E27F6BF` FOREIGN KEY (`categories_id`) REFERENCES `category` (`id`);

ALTER TABLE `response`
  ADD CONSTRAINT `FK_3E7B0BFB1E27F6BF` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
